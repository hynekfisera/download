﻿using System;
using System.Diagnostics;

namespace Zasobnik
{
    //datova struktura typu LIFO - last in first out
    //krok zpet, prohledavani/vytvareni bludiste, postfix zapis matematickych vyrazu
    class Zasobnik
    {
        //pole, do ktereho budeme ukladat hodnoty
        private int[] zasobnik;
        //ukazatel na pozici indexu posledniho vkladaneho prvku
        private int top;
        private int count;

        //pri vytvareni noveho zasobniku urcime jeho maximalni velikost a pozice vrcholu bude mimo zasobnik
        public Zasobnik(int max)
        {
            zasobnik = new int[max];
            top = -1;
            count = 0;
        }
        //test jestli je zasobnik prazdny
        bool Empty()
        {
            return top < 0;
        }

        public int Count()
        {
            return count;
        }

        //metoda pro vlozeni prvku do zasobniku PUSH
        //navratovy typ bool, jestli se vlozeni povedlo
        //vstupni promenna je int
        public bool Push(int idk)
        {
            //otestujeme jestli nejsme na konci zasobniku (nedoslo k preteceni)
            if (top >= zasobnik.Length - 1)
            {
                Console.WriteLine("Stack overflow");
                return false;
            }
            else
            {
                count++;
                //v pripade, ze muzeme prvek vlozit, zvysime hodnotu aktualni pozice vrcholu zasobniku o jedna a vlozime novou hodnotu
                //++top nejdrive dojde k top=top+1 a teprve potom se hodnota pouzije jako index
                zasobnik[++top] = idk;
                return true;
            }
        }
        //metoda pro vybrani prvku ze zasobniku
        public int Pop()
        {
            if (top < 0)
            {
                Console.WriteLine("Stack underflow");
                return -1;
            }
            else
            {
                count--;
                return zasobnik[top--];
            }
        }
        //metoda pro vypsání aktuálního prvku na vrcholu zásobníku bez toho, aby se odebral
        public int Peek()
        {
            if (top < 0)
            {
                Console.WriteLine("Stack underflow");
                return -1;
            }
            else
            {
                return zasobnik[top];
            }
        }
        //metoda pro vypis vsech prvku v zasobniku
        public void VypisVse()
        {
            if (count > 0)
            {
                Console.WriteLine("V zasobniku jsou hodnoty: ");
                //prochazime pole od hodnoty indexu top az prvnimu indexu 0
                for (int i = top; i >= 0; i++)
                {
                    Console.WriteLine(zasobnik[i]);
                }
            }
            else
            {
                Console.WriteLine("Stack underflow");
            }
        }

        public void Clear()
        {
            Array.Clear(zasobnik, 0, zasobnik.Length);
            top = -1;
            count = 0;
        }

        //destructor
        /*
        ~Zasobnik()
        {

        }*/
    }
}
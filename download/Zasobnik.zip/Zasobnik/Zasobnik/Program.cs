﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zasobnik
{
    class Program
    {
        static void Main(string[] args)
        {
            //nova instance tridy Zasobnik s 10 prvky
            Zasobnik zasobnik = new Zasobnik(10);
            //vlozeni prvku do zasobniku
            zasobnik.Push(5);
            zasobnik.Push(2);
            zasobnik.Push(3);
            zasobnik.Push(1);
            //vypis prvku na vrcholu zasobniku
            Console.WriteLine(zasobnik.Peek());
            //odebrani prvku
            zasobnik.Pop();
            Console.WriteLine(zasobnik.Peek());
            //pocet prvku v zasobniku
            Console.WriteLine(zasobnik.Count());

            Stack<int> stack = new Stack<int>();
            stack.Push(10);
            stack.Push(5);
            stack.Push(1);
            stack.Push(30);
            Console.WriteLine($"Pocet prvku v zasobniku je {stack.Count} a hodnota na vrcholu je {stack.Peek()}");
            stack.Pop();
            Console.WriteLine($"Pocet prvku v zasobniku je {stack.Count} a hodnota na vrcholu je {stack.Peek()}");

            Console.ReadKey();
        }
    }
}

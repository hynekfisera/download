﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ukolCSV
{
    class Program
    {
        static void Main(string[] args)
        {
            bool conv;
            int akce;
            string soubor;
            string[] automobil = new string[3];
            Console.WriteLine("Informace o automobilech - CSV");
            Console.WriteLine("Co chcete udělat?");
            Console.WriteLine("[1] Načíst informace o automobilech z CSV souboru");
            Console.WriteLine("[2] Zapsat nový automobil do CSV souboru");
            conv = Int32.TryParse(Console.ReadLine(), out akce);
            switch (akce)
            {
                case 1:
                    Console.WriteLine("Zadejte název souboru i s příponou:");
                    soubor = Console.ReadLine();
                    Vypsat(soubor);
                    break;
                case 2:
                    Console.WriteLine("Zadejte název souboru i s příponou:");
                    soubor = Console.ReadLine();
                    Console.WriteLine("Zadejte značku automobilu:");
                    automobil[0] = Console.ReadLine();
                    Console.WriteLine("Zadejte rok výroby:");
                    automobil[1] = Console.ReadLine();
                    Console.WriteLine("Zadejte najeté kilometry:");
                    automobil[2] = Console.ReadLine();
                    Zapsat(soubor, automobil);
                    break;
                default:
                    Console.WriteLine("Bylo zadáno neplatné číslo!");
                    break;
            }
            Console.ReadKey();
        }
        static void Vypsat(string soubor)
        {
            string[] obsah;
            obsah = File.ReadAllLines(soubor);
            foreach (string linka in obsah)
            {
                string[] automobil = linka.Split(';');
                Console.WriteLine($"Značka: {automobil[0]}; Rok výroby: {automobil[1]}; Najeté kilometry: {automobil[2]}");
            }

            Console.WriteLine("Výpis byl dokončen!");
        }
        static void Zapsat(string soubor, string[] automobil)
        {
            File.AppendAllText(soubor, $"{automobil[0]};{automobil[1]};{automobil[2]}\n");
            Console.WriteLine("Zápis byl dokončen!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace souboryUkol
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zadejte cestu k souborům:");
            string path = Console.ReadLine();
            ProchazetSoubory(path);
            Console.ReadKey();
        }

        static void ProchazetSoubory(string path)
        {
            foreach (var dir in Directory.GetDirectories(path))
            {
                foreach (var file in Directory.GetFiles(dir))
                {
                    if (file.EndsWith(".txt"))
                    {
                        string obsah;
                        obsah = File.ReadAllText(file);
                        File.AppendAllText("obsah.txt", obsah);
                    }
                }
                ProchazetSoubory(dir);
            }
        }
    }
}
